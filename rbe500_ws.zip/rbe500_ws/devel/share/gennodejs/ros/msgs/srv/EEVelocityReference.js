// Auto-generated. Do not edit!

// (in-package msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class EEVelocityReferenceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.x_ref_vel = null;
      this.y_ref_vel = null;
      this.z_ref_vel = null;
    }
    else {
      if (initObj.hasOwnProperty('x_ref_vel')) {
        this.x_ref_vel = initObj.x_ref_vel
      }
      else {
        this.x_ref_vel = 0.0;
      }
      if (initObj.hasOwnProperty('y_ref_vel')) {
        this.y_ref_vel = initObj.y_ref_vel
      }
      else {
        this.y_ref_vel = 0.0;
      }
      if (initObj.hasOwnProperty('z_ref_vel')) {
        this.z_ref_vel = initObj.z_ref_vel
      }
      else {
        this.z_ref_vel = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type EEVelocityReferenceRequest
    // Serialize message field [x_ref_vel]
    bufferOffset = _serializer.float64(obj.x_ref_vel, buffer, bufferOffset);
    // Serialize message field [y_ref_vel]
    bufferOffset = _serializer.float64(obj.y_ref_vel, buffer, bufferOffset);
    // Serialize message field [z_ref_vel]
    bufferOffset = _serializer.float64(obj.z_ref_vel, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type EEVelocityReferenceRequest
    let len;
    let data = new EEVelocityReferenceRequest(null);
    // Deserialize message field [x_ref_vel]
    data.x_ref_vel = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [y_ref_vel]
    data.y_ref_vel = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [z_ref_vel]
    data.z_ref_vel = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 24;
  }

  static datatype() {
    // Returns string type for a service object
    return 'msgs/EEVelocityReferenceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f924e7be3ed156f8ed283c16bc3671e5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 x_ref_vel
    float64 y_ref_vel
    float64 z_ref_vel
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new EEVelocityReferenceRequest(null);
    if (msg.x_ref_vel !== undefined) {
      resolved.x_ref_vel = msg.x_ref_vel;
    }
    else {
      resolved.x_ref_vel = 0.0
    }

    if (msg.y_ref_vel !== undefined) {
      resolved.y_ref_vel = msg.y_ref_vel;
    }
    else {
      resolved.y_ref_vel = 0.0
    }

    if (msg.z_ref_vel !== undefined) {
      resolved.z_ref_vel = msg.z_ref_vel;
    }
    else {
      resolved.z_ref_vel = 0.0
    }

    return resolved;
    }
};

class EEVelocityReferenceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type EEVelocityReferenceResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type EEVelocityReferenceResponse
    let len;
    let data = new EEVelocityReferenceResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'msgs/EEVelocityReferenceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '937c9679a518e3a18d831e57125ea522';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string message 
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new EEVelocityReferenceResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: EEVelocityReferenceRequest,
  Response: EEVelocityReferenceResponse,
  md5sum() { return 'ce440340b1234e7f8e199ae99362b9b3'; },
  datatype() { return 'msgs/EEVelocityReference'; }
};
