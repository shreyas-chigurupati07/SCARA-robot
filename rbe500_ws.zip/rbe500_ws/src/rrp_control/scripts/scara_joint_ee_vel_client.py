#!/usr/bin/env python3

import rospy
from msgs.srv import EEVelocity, EEVelocityRequest
import sys

def set_desired_ee_velocity_client(x_vel, y_vel, z_vel):
    rospy.wait_for_service("end_effector_vels_to_joint_vels")
    try:
        end_effector_velocity = rospy.ServiceProxy("end_effector_vels_to_joint_vels", EEVelocity)
        req = EEVelocityRequest()
        req.x_vel = x_vel
        req.y_vel = y_vel 
        req.z_vel = z_vel
        response = end_effector_velocity(req)
        return response.success, response.message
    except rospy.ServiceException as e:
        rospy.logerr(f"Failed to call end_effector_vels_to_joint_vels: {e}")
        return False, ""

if __name__ == "__main__":
    rospy.init_node("end_effector_vels_to_joint_vels_client")
    if len(sys.argv) < 3:
        sys.exit(1)

    x_vel = float(sys.argv[1])
    y_vel = float(sys.argv[2])
    z_vel = float(sys.argv[3])
    success, message = set_desired_ee_velocity_client(x_vel, y_vel, z_vel)
    if success:
        rospy.loginfo(f"Desired end effector velocity set to x_dot : {x_vel} y_dot : {y_vel}, z_dot : {z_vel}")
    else:
        rospy.logerr(f"Failure: {message}")