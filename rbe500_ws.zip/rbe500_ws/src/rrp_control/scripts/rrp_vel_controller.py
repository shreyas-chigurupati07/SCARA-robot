#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64
from msgs.srv import JointVelocities, JointVelocitiesResponse


def set_joint_velocity_desired_callback(req):

    global joint_velocity_desired

    joint_velocity_desired[0] = req.q1_dot *2  
    joint_velocity_desired[1] = req.q2_dot *2
    joint_velocity_desired[2] = req.q3_dot *2

    return JointVelsResponse(True, f"Desired joint velocities set successfully to joint1 :  {joint_velocity_desired[0]}, Desired Joint Position 2 : {joint_velocity_desired[1]}, Desired Joint Position 3 : {joint_velocity_desired[2]} ")

joint_velocity_curr = [0, 0, 0]
joint_error = [0, 0, 0]

kp = [7.3, 5.5, 6]
ki = [0.1, 0.0, 0.0]
kd = [0.5, 0.1, 0.1]

joint_velocity_desired = [0.0 , 0.0, 0.0]
joint_pos_curr = [0.0, 0.0, 0.0]



def joint_states_callback(msg):
    
    joint_pos_curr[0] = msg.position[0]

    joint_velocity_curr[0] = msg.velocity[0]
    joint_velocity_curr[1] = msg.velocity[1]
    joint_velocity_curr[2] = msg.velocity[2]
    print(f"velocity joint 1 : {joint_velocity_curr[0]}")
    print(f"velocity joint 2 : {joint_velocity_curr[1]}")
    print(f"velocity joint 3 : {joint_velocity_curr[2]}")
    print('\n\n')


    # Calculating Joint errors. 
    joint_error1 = joint_velocity_desired[0] - joint_velocity_curr[0]
    joint_error2 = joint_velocity_desired[1] - joint_velocity_curr[1]
    joint_error3 = joint_velocity_desired[2] - joint_velocity_curr[2]
    
    joint_velocity_effort1 = (kp[0]*joint_error1) + (kd[0]*(joint_error1 - joint_error[0])) + (ki[0]*(joint_error1 + joint_error[0]))  
    joint_velocity_effort2 = (kp[1]*joint_error2) + (kd[1]*(joint_error2 - joint_error[1])) + (ki[1]*(joint_error2 + joint_error[1]))
    joint_velocity_effort3 = (kp[2]*joint_error3) + (kd[2]*(joint_error3 - joint_error[2])) + (ki[2]*(joint_error3 + joint_error[2]))
    print(f"joint_effort given to joint 1 : {joint_velocity_effort1}")
    print(f"joint_effort given to joint 2 : {joint_velocity_effort2}")    
    print(f"joint_effort given to joint 3 : {joint_velocity_effort3}")    
    print('\n\n')
    
    joint_error[0] = joint_error1
    joint_error[1] = joint_error2
    joint_error[2] = joint_error3
    joint_velocity_effort3 = -1.0
    
    pub3 = rospy.Publisher('/rrp/joint3_effort_controller/command', Float64, queue_size=10)
    effort_command = Float64()
    effort_command.data = joint_velocity_effort3
    pub3.publish(joint_velocity_effort3)
    
    pub2 = rospy.Publisher('/rrp/joint2_effort_controller/command', Float64, queue_size=10)
    effort_command = Float64()
    effort_command.data = joint_velocity_effort2
    pub2.publish(joint_velocity_effort2)
    
    pub1 = rospy.Publisher('/rrp/joint1_effort_controller/command', Float64, queue_size=10)
    effort_command = Float64()
    effort_command.data = joint_velocity_effort1
    pub1.publish(joint_velocity_effort1)

if __name__ == '__main__':    
    rospy.init_node('velocity_pd_controller')
    rospy.Service("set_joint_velocity_desired", JointVels,
                  set_joint_velocity_desired_callback)
    
    rospy.Subscriber('rrp/joint_states', JointState, joint_states_callback)
    
    rospy.spin()