#!/usr/bin/env python3
import rospy
import numpy as np
import math
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Pose
from geometry_msgs.msg import Twist
from msgs.srv import JointVelocities, JointVelocitiesRequest, JointVelocitiesResponse
from msgs.srv import EEVelocity, EEVelocityRequest, EEVelocityResponse

# Dimensions of the SCARA Manipulator
L1 = 0.2
L2 = 0.2
L3 = 0.2
# Joint Angles
q1 = 1.57
q2 = -1.57
q3 = 0.1

def dh_matrix(theta, d, a, alpha):
    T = np.array([[np.cos(theta), -np.sin(theta)*np.cos(alpha), np.sin(theta)*np.sin(alpha), a*np.cos(theta)],
                  [np.sin(theta), np.cos(theta)*np.cos(alpha), -np.cos(theta)*np.sin(alpha), a*np.sin(theta)],
                  [0, np.sin(alpha), np.cos(alpha), d],
                  [0, 0, 0, 1]])
    return T

def joint_vel2ee_vel_service_callback(srv_msg):

    # Extract Joint velocities    
    q1_vel = srv_msg.q1_vel 
    q2_vel = srv_msg.q2_vel
    q3_vel = srv_msg.q3_vel
    
    Q_vel = np.array([q1_vel, q2_vel, q3_vel]) 

    # Calculate Jacobian
    a1, a2, a3 = L2, L3, 0                     
    alpha1, alpha2, alpha3 = 0, np.pi, 0       
    d1, d2, d3 = L1, 0, q3                     

    T01 = np.identity(4)
    T12 = np.around(dh_matrix(q1, d1, a1, alpha1),decimals=4)
    T23 = np.around(dh_matrix(q2, d2, a2, alpha2),decimals=4)
    T34 = np.around(dh_matrix(0, d3, a3, alpha3),decimals=4)

    T01 = np.array([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]])
    T02 = T12
    T03 = np.dot(T12, T23)
    T04 = np.dot(np.dot(T12, T23), T34)
    z1 = T01[:3,2]
    z2 = T02[:3,2]
    z3 = T03[:3,2]
    z4 = T04[:3,2]
    p01 = T01[:3,3]
    p02 = T02[:3,3]
    p03 = z3
    pe  = T04[:3,3]
              
    Jp1 = np.cross(z1, (pe - p01))
    Jp2 = np.cross(z2, (pe - p02))
    Jp3 = z3
 
    Jacobian = np.transpose(np.array([Jp1,Jp2,Jp3])) 

    # Calculate end effector velocities
    end_effector_vel = np.around(np.dot(Jacobian, Q_vel), decimals=2)

    # Print the Values. 
    print("[x_dot y_dot z_dot]", end_effector_vel)

    return JointVelsResponse(True, f"The Calculated End Effector Velocity is : {end_effector_vel}")

###################################
# END EFFECTOR VEL. to JOINT VEL. 
###################################
def ee_vel2joint_vel_service_callback(srv_msg):
    # Extract End Effector velocities    
    x_vel = srv_msg.x_vel 
    y_vel = srv_msg.y_vel
    z_vel = srv_msg.z_vel

    P_vel = np.array([x_vel, y_vel, z_vel])

    # Calculate Jacobian
    # Calculate Jacobian
    a1, a2, a3 = L2, L3, 0                     
    alpha1, alpha2, alpha3 = 0, np.pi, 0       
    d1, d2, d3 = L1, 0, q3                     

    T01 = np.identity(4)
    T12 = np.around(dh_matrix(q1, d1, a1, alpha1),decimals=4)
    T23 = np.around(dh_matrix(q2, d2, a2, alpha2),decimals=4)
    T34 = np.around(dh_matrix(0, d3, a3, alpha3),decimals=4)

    T01 = np.array([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]])
    T02 = T12
    T03 = np.dot(T12, T23)
    T04 = np.dot(np.dot(T12, T23), T34)
    z1 = T01[:3,2]
    z2 = T02[:3,2]
    z3 = T03[:3,2]
    z4 = T04[:3,2]
    p01 = T01[:3,3]
    p02 = T02[:3,3]
    p03 = z3
    pe  = T04[:3,3]
              
    Jp1 = np.cross(z1, (pe - p01))
    Jp2 = np.cross(z2, (pe - p02))
    Jp3 = z3
 
    Jacobian = np.transpose(np.array([Jp1,Jp2,Jp3])) 

    # Calculate end effector velocities
    joint_vel = np.around(np.dot(np.linalg.pinv(Jacobian), P_vel) , decimals=2)

    # Print the Values. 
    print("[q1_vel q2_vel q3_vel]", joint_vel)

    return EEVelocityResponse(True, f"The Calculated Joint Velocities are : {joint_vel}")

if __name__ == '__main__':  

    # For node 
    rospy.init_node('scara_velocity_kinematics')

    # (Service-Client)
    rospy.Service("joint_vels_to_end_effector_vels", JointVelocities,
                  joint_vel2ee_vel_service_callback)
    
    rospy.Service("end_effector_vels_to_joint_vels", EEVelocity,
                  ee_vel2joint_vel_service_callback)
    
    rospy.loginfo(
        "Scara Position controller is ready to receive joint position")
    
    rospy.spin()