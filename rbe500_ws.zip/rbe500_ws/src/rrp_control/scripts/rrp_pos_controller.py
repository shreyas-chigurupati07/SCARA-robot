#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import JointState
from rbe500_homework_1.srv import Multiply, MultiplyResponse
import sys
import time
import csv
import os
from std_msgs.msg import Float64

current_joint_position = [0, 0, 0]

previous_joint_error = [0, 0, 0]

kp = [25.0,     27.0,       25.0]
ki = [0.0,      0.0,         0.0]
kd = [14.0,     20.0,       94.8]

desired_joint_position = [0, 0, 0]

def joint_states_callback(msg):
    
    current_joint_position[0] = msg.position[0]
    current_joint_position[1] = msg.position[1]
    current_joint_position[2] = msg.position[2]
    print(f"current position joint 1 : {current_joint_position[0]}")
    print(f"current position joint 2 : {current_joint_position[1]}")
    print(f"current position joint 3 : {current_joint_position[2]}")
    print('\n\n')

    # Calculating all Joint errors. 
    joint_error1 = desired_joint_position[0] - current_joint_position[0]
    joint_error2 = desired_joint_position[1] - current_joint_position[1]
    joint_error3 = desired_joint_position[2] - current_joint_position[2]
    print(f"position error joint 1 : {joint_error1}")
    print(f"position error joint 2 : {joint_error2}")
    print(f"position error joint 3 : {joint_error3}")
    print('\n\n')

    # Calculating all joint efforts
    joint_position_effort1 = (kp[0]*joint_error1) + (kd[0]*(joint_error1 - previous_joint_error[0])) + (ki[0]*(joint_error1 + previous_joint_error[0]))   
    joint_position_effort2 = (kp[1]*joint_error2) + (kd[1]*(joint_error2 - previous_joint_error[1])) + (ki[1]*(joint_error2 + previous_joint_error[1]))
    joint_position_effort3 = (kp[2]*joint_error3) + (kd[2]*(joint_error3 - previous_joint_error[2])) + (ki[2]*(joint_error3 + previous_joint_error[2]))
    print(f"joint_effort_to be given to joint 1 : {joint_position_effort1}")
    print(f"joint_effort_to be given to joint 2 : {joint_position_effort2}")    
    print(f"joint_effort_to be given to joint 3 : {joint_position_effort3}")    
    print('\n\n')
    
    # Setting current effort value as previous effort value for next iteration. 
    previous_joint_error[0] = joint_error1
    previous_joint_error[1] = joint_error2
    previous_joint_error[2] = joint_error3

    # Joint 3 Publisher
    pub3 = rospy.Publisher('/rrp/joint3_effort_controller/command', Float64, queue_size=10)
    effort_command = Float64()
    effort_command.data = joint_position_effort3
    pub3.publish(joint_position_effort3)
    
    # Joint 2 Publisher
    pub2 = rospy.Publisher('/rrp/joint2_effort_controller/command', Float64, queue_size=10)
    effort_command = Float64()
    effort_command.data = joint_position_effort2
    pub2.publish(joint_position_effort2)
    
    # Joint 1 Publisher
    pub1 = rospy.Publisher('/rrp/joint1_effort_controller/command', Float64, queue_size=10)
    effort_command = Float64()
    effort_command.data = joint_position_effort1
    pub1.publish(joint_position_effort1)
    
####################################################
## SERVICE CALLBACK FOR SETTING THE DESIRED ANGLES
####################################################

def set_desired_joint_position_callback(req):

    global desired_joint_position

    desired_joint_position[0] = req.data1
    desired_joint_position[1] = req.data2
    desired_joint_position[2] = req.data3 
    return MultiplyResponse(True, f"Desired joint positions set successfully to joint1 :  {desired_joint_position[0]}, Desired Joint Position 2 : {desired_joint_position[1]}, Desired Joint Position 3 : {desired_joint_position[2]} ")

if __name__ == '__main__':    
    
    # For node 
    rospy.init_node('pd_controller')
    
    # For Desired Joint States (Service-Client)
    rospy.Service("set_desired_joint_position", Multiply,
                  set_desired_joint_position_callback)

    # For Joint States
    rospy.Subscriber('/rrp/joint_states', JointState, joint_states_callback)
    

    rospy.loginfo(
        "Scara Position controller is ready to receive the desired joint position")
    
    rospy.spin()