#!/usr/bin/env python3
from __future__ import print_function
import rospy
from rbe500_homework_1.srv import Multiply, MultiplyResponse

def multiplication_client(a, b):
    rospy.wait_for_service('multiply_service')
    try:
        multiplication_service = rospy.ServiceProxy('multiply_service', Multiply)
        resp = multiplication_service(a, b)
        return resp.product
    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)

if __name__ == '__main__':
    try:
        a = int(input("Enter the first number: "))
        b = int(input("Enter the second number: "))
        print("Multiplying {} and {}: {}".format(a, b, multiplication_client(a, b)))
    except ValueError:
        print("Please enter a valid number.")

