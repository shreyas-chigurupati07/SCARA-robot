#!/usr/bin/env python3
import rospy
from rbe500_homework_1.srv import Multiply, MultiplyResponse

def callback(msg):
    result = msg.a * msg.b
    rospy.loginfo(f"Multiplying {msg.a} and {msg.b} and sending back the result: {result}")
    return MultiplyResponse(result)

def multiply_server():
    rospy.init_node("multiply_server")
    server = rospy.Service("multiply_service", Multiply, callback)
    rospy.spin()

if __name__ == "__main__":
    multiply_server()



