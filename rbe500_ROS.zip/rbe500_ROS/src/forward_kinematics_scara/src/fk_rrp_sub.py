#!/usr/bin/env python3
import rospy
import numpy as np
import math
from sensor_msgs.msg import JointState

def dh_matrix(a, alpha, d, theta):
    # Function to calculate the DH matrix from a set of DH parameters
    T = np.array([[np.cos(theta), -np.sin(theta)*np.cos(alpha), np.sin(theta)*np.sin(alpha), a*np.cos(theta)],
                  [np.sin(theta), np.cos(theta)*np.cos(alpha), -np.cos(theta)*np.sin(alpha), a*np.sin(theta)],
                  [0, np.sin(alpha), np.cos(alpha), d],
                  [0, 0, 0, 1]])
    return T

def calculate_ee_pose(q1, q2, q3):
    # Enter the DH parameters for the robot

    a1 = 0 #l2
    a2 = 0 #l3 
    a3 = 0 

    pi = math.pi
    
    alpha1 = 0
    alpha2 = 0
    alpha3 = pi
    
    d1 = 0
    d2 = 0 
    d3 = -q3 # prismatic joint varialble q3
 
    
    # Transformation matrices
    T01 = dh_matrix(a1, alpha1, d1, q1)
    T12 = dh_matrix(a2, alpha2, d2, q2)
    T23 = dh_matrix(a3, alpha3, d3, 0)


    # Calculate the end effector transformation matrix (End Effector Pose)
    T04 = (np.dot(np.dot(T01, T12), T23))
    
    # End effector pose from the transformation matrix
    ee_pose = np.array([T04[0,3], T04[1,3], T04[2,3]])
    return ee_pose

def joint_state_callback(data):
    # Extract the joint values from the received message
     
    q1 = data.position[0]
    q2 = data.position[1]
    q3 = data.position[2]

    
    ee_pose = calculate_ee_pose(q1, q2, q3)
    print("End Effector Pose: ", ee_pose)

if __name__ == '__main__':
    rospy.init_node('ee_pose_calculator')
    rospy.Subscriber('/rrp/joint_states', JointState, joint_state_callback)
    rospy.spin()