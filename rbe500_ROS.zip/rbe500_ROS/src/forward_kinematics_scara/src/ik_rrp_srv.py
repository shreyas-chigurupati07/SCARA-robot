#!/usr/bin/env python3
import rospy
import numpy as np
from forward_kinematics_scara.srv import joints, jointsResponse

def rrp_callback(srv_msg):
    print(srv_msg)
    # Extracting the message from Service
    ee_x = srv_msg.a
    ee_y = srv_msg.b
    ee_z = srv_msg.c


    a1 = 0.2
    a2 = 0.2
    d4 = 0.2

    c2 = (ee_x*2 + ee_y*2 - (a1*2 + a2*2))/2*a1*a2
    s2 = np.sqrt(1 - c2**2)

    theta_1 =  np.arctan2(ee_y,ee_x) - (np.arctan2(a2*s2,a1+(a2*c2)))
    theta_2 = np.arctan2(s2,c2)
    d3 = d4 - ee_z

    q1 = theta_1
    q2 = theta_2
    q3 = d3

    rospy.loginfo(f"q1 = {q1}, q2 = {q2}, q3 = {q3}")

    return jointsResponse(q1, q2, q3)

    

def rrp_invk_server():
    rospy.init_node("rrp_invk_server")
    server = rospy.Service("rrp_invk_service", joints, rrp_callback)
    rospy.spin()

if __name__ == "__main__":
    rrp_invk_server()