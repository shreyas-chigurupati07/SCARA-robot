#!/usr/bin/env python3
import rospy
from forward_kinematics_scara.srv import joints, jointsRequest

def rrp_invk_client(x, y, z):
    rospy.wait_for_service("rrp_invk_service")
    try:
        rrp_invk_service = rospy.ServiceProxy("rrp_invk_service", joints)
        request = jointsRequest(x, y, z)
        response = rrp_invk_service(request)
        rospy.loginfo(f"Received!! SCARA Inverse Kinematics solution: q1 = {response.q1}, q2 = {response.q2}, q3 = {response.q3}")
    except rospy.ServiceException as e:
        rospy.logerr(f"Service call failed: {e}")

if __name__ == "__main__":
    rospy.init_node("rrp_invk_client")
    x = 0.2
    y = -0.2
    z = 0.1
    rrp_invk_client(x, y, z)