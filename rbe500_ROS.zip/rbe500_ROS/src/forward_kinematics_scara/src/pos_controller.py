# # #!/usr/bin/env python3
# # import rospy
# # import numpy as np
# # import math
# # from sensor_msgs.msg import JointState
# # from gazebo_msgs.msg import ApplyJointEffort, ApplyJointEffortRequest

# #!/usr/bin/env python3

# import rospy
# from std_msgs.msg import Float64
# from gazebo_msgs.msg import LinkStates
# from gazebo_msgs.srv import ApplyJointEffort, ApplyJointEffortRequest
# from rrp_robot.msg import JointPositions
# import numpy as np



# class PositionController:
#     def __init__(self):
#         # Initialize ROS node
#         rospy.init_node('position_controller')

#         # Get the joint positions
#         self.joint_positions = None
#         rospy.Subscriber('/gazebo/link_states', LinkStates, self.joint_positions_callback)

#         # Set up publisher for sending joint efforts
#         self.effort_pub = rospy.Publisher('/gazebo/apply_joint_effort', ApplyJointEffort, queue_size=10)

#         # Set up service for setting reference position
#         rospy.Service('set_reference_position', JointPositions, self.set_reference_position_callback)

#     def joint_positions_callback(self, msg):
#         # Get index of last joint (assume there are no more than 3 links in the model)
#         link_names = msg.name
#         last_joint_index = -1
#         for i in range(len(link_names)):
#             if 'joint' in link_names[i]:
#                 last_joint_index = i
#         if last_joint_index == -1:
#             return

#         # Get current position of last joint
#         link_pose = msg.pose[last_joint_index]
#         quat = link_pose.orientation
#         euler = tf.transformations.euler_from_quaternion([quat.x, quat.y, quat.z, quat.w])
#         self.current_position = euler[0]

#         # Record joint positions in text file
#         with open(self.filename, 'a') as file:
#             file.write('{:.2f}, {:.2f}\n'.format(self.reference_position, self.current_position))

#         # Compute joint effort using PD controller
#         error = self.reference_position - self.current_position
#         effort = self.Kp * error + self.Kd * (error - self.prev_error)
#         self.prev_error = error

#         # Send joint effort to Gazebo
#         effort_msg = ApplyJointEffortRequest()
#         effort_msg.joint_name = 'joint3'
#         effort_msg.effort = effort
#         effort_msg.start_time = rospy.Time.now()
#         effort_msg.duration = rospy.Duration(0.1)  # Apply effort for 0.1 seconds
#         self.effort_pub.publish(effort_msg)

#     def set_reference_position_callback(self, req):
#         self.reference_position = req.positions[2]  # Get reference position for last joint

# if __name__ == '__main__':
#     controller = PositionController()
#     rospy.spin()







####################### CHAT GPT Code ################################

#!/usr/bin/env python3

import rospy
from std_msgs.msg import Float64
from gazebo_msgs.msg import LinkStates
from gazebo_msgs.srv import ApplyJointEffort, ApplyJointEffortResponse
from sensor_msgs.msg import JointState
from tf.transformations import quaternion_from_euler
import numpy as np

class PositionController:
    def __init__(self):
        # Initialize ROS node
        rospy.init_node('position_controller')

        # Get the joint positions
        self.joint_positions = None
        rospy.Subscriber('/gazebo/link_states', LinkStates, self.joint_positions_callback)

        # Set up publisher for sending joint efforts
        self.effort_pub = rospy.Publisher('/gazebo/apply_joint_effort', ApplyJointEffort, queue_size=10)

        # Set up service for setting reference position
        rospy.Service('set_reference_position', JointState, self.set_reference_position_callback)

        # PD controller parameters for last joint
        self.Kp = 200
        self.Kd = 5

        # Initialize variables for reference position and current position
        self.reference_position = 0
        self.current_position = 0

        # Set up text file for recording joint positions
        self.filename = 'joint_positions.txt'
        with open(self.filename, 'w') as file:
            file.write('Reference Position, Current Position\n')

    def joint_positions_callback(self, msg):
        # Get index of last joint (assume there are no more than 3 links in the model)
        link_names = msg.name
        last_joint_index = -1
        for i in range(len(link_names)):
            if 'joint' in link_names[i]:
                last_joint_index = i
        if last_joint_index == -1:
            return

        # Get current position of last joint
        link_pose = msg.pose[last_joint_index]
        quat = link_pose.orientation
        euler = quaternion_from_euler([quat.x, quat.y, quat.z, quat.w])
        self.current_position = euler[0]

        # Record joint positions in text file
        with open(self.filename, 'a') as file:
            file.write('{:.2f}, {:.2f}\n'.format(self.reference_position, self.current_position))

        # Compute joint effort using PD controller
        error = self.reference_position - self.current_position
        effort = self.Kp * error + self.Kd * (error - self.prev_error)
        self.prev_error = error

        # Send joint effort to Gazebo
        effort_msg = ApplyJointEffortResponse()
        effort_msg.joint_name = 'joint3'
        effort_msg.effort = effort
        effort_msg.start_time = rospy.Time.now()
        effort_msg.duration = rospy.Duration(0.1)  # Apply effort for 0.1 seconds
        self.effort_pub.publish(effort_msg)

    def set_reference_position_callback(self, req):
        self.reference_position = req.positions[2]  # Get reference position for last joint

if __name__ == '__main__':
    controller = PositionController()
    rospy.spin()















# #!/usr/bin/env python3

# import rospy
# from std_srvs.srv import SetBool, SetBoolResponse
# from sensor_msgs.msg import JointState
# from gazebo_msgs.srv import ApplyJointEffort, ApplyJointEffortResponse

# # Define the gains for the PD controller
# KP = 1.0
# KD = 0.1

# # Define the joint names for the robot
# JOINT_NAMES = ['joint1', 'joint2', 'joint3']

# # Define the index of the last joint
# LAST_JOINT_INDEX = 2

# # Define the maximum effort that can be applied to the joint
# MAX_EFFORT = 10.0

# # Define the position tolerance for the service
# POSITION_TOLERANCE = 0.01


# def joint_states_callback(msg):

#     current_time = rospy.get_time()
#     if last_time is not None:
#         dt = current_time - last_time
#     else:
#         dt = 0
#     last_time = current_time

#     # Extract the joint positions from the JointState message
#     joint_positions = msg.position

#     # Get the position of the last joint
#     last_joint_position = joint_positions[LAST_JOINT_INDEX]

#     # Compute the error between the current position and the target position
#     position_error = target_position - last_joint_position

#     # Compute the derivative of the error
#     if last_joint_position is not None:
#         position_error_deriv = position_error/ dt
#     else:
#         position_error_deriv = 0.0

#     # Compute the control effort using a PD controller
#     control_effort = KP * position_error + KD * position_error_deriv

#     # Apply the control effort to the last joint
#     apply_joint_effort(control_effort,dt)

#     # Record the current position and error for plotting later
#     current_positions.append(last_joint_position)
#     position_errors.append(position_error)

# def apply_joint_effort(effort, duration):
#     # Create a request to apply a joint effort to the last joint
#     request = ApplyJointEffortResponse()
#     request.joint_name = JOINT_NAMES[LAST_JOINT_INDEX]
#     request.effort = min(max(effort, -MAX_EFFORT), MAX_EFFORT)  # Clamp the effort to the maximum allowed
#     request.duration = rospy.Duration.from_sec(duration)

#     # Call the apply_joint_effort service to apply the effort to the joint
#     apply_joint_effort_service(request)

# def move_to_position_service_callback(req):
#     # Get the target position from the service request
#     global target_position
#     target_position = req.data

#     # Wait for the current position to be close to the target position
#     while abs(last_joint_position - target_position) > POSITION_TOLERANCE:
#         rospy.sleep(0.1)

#     # Return a response indicating that the movement was successful
#     response = SetBoolResponse()
#     response.success = True
#     return response


# if __name__ == '__main__':
#     # Initialize the node
#     rospy.init_node('position_controller')

#     # Subscribe to the joint_states topic
#     rospy.Subscriber('/rrp/joint_states', JointState, joint_states_callback)

#     # Initialize the apply_joint_effort service client
#     rospy.wait_for_service('/gazebo/apply_joint_effort')
#     apply_joint_effort_service = rospy.ServiceProxy('/gazebo/apply_joint_effort', ApplyJointEffort)

#     # Initialize the move_to_position service
#     move_to_position_service = rospy.Service('/move_to_position', SetBool, move_to_position_service_callback)

#     # Initialize the variables for the PD controller and plotting
#     last_joint_position = None
