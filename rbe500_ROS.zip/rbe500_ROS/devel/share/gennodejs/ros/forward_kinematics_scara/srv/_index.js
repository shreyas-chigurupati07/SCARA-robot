
"use strict";

let joints = require('./joints.js')

module.exports = {
  joints: joints,
};
